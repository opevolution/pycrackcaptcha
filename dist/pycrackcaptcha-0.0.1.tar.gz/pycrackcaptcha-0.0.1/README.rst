========
PyCrackCaptcha
========

.. image:: 
   :target: 

.. _PyCrackCaptcha-synopsis:

.. contents::
    :local:

.. _PyCrackCaptcha-implemented-bank:

.. _PyCrackCaptcha-docs:

.. _PyCrackCaptcha_sample.py: https://github.com/eduardocereto/pyboleto/blob/master/bin/pyboleto_sample.py

.. _PyCrackCaptcha-installation:

Installation
============

License
=======

This software is licensed under the `New BSD License`. See the ``LICENSE``
file in the top distribution directory for the full license text.

.. vim:tw=0:sw=4:et
